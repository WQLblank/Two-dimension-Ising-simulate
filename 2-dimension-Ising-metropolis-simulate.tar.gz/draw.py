import numpy as np
import matplotlib.pyplot as plt

x,y=[],[]
tmp1,tmp2='',''
file_object = open('data.txt')

for line in file_object:
    (tmp1,tmp2)=line.split()
    x.append(tmp1)
    y.append(tmp2)
file_object.close()
x = [float(x) for x in x if x]
y = [float(y) for y in y if y]

fig = plt.figure()
ax = fig.add_subplot(111)
ax.scatter(x,y, c= 'r')

plt.plot(x,y)
plt.show()



